// lib/services/database_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/user_model.dart';

class DatabaseService {
  final _client = Supabase.instance.client;
  static const _table = 'submissions';

  // CREATE
  Future<void> createRecord(UserModel user) async {
    await _client.from(_table).insert(user.toMap());
  }

  // READ
  Future<List<UserModel>> fetchRecords() async {
    final response = await _client
        .from(_table)
        .select()
        .order('created_at', ascending: false);
    return (response as List)
        .map((row) => UserModel.fromMap(row))
        .toList();
  }

  // UPDATE
  Future<void> updateRecord(UserModel user) async {
    await _client
        .from(_table)
        .update(user.toMap())
        .eq('id', user.id!);
  }

  // DELETE
  Future<void> deleteRecord(int id) async {
    await _client.from(_table).delete().eq('id', id);
  }
}
