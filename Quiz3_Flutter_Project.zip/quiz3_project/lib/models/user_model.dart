// lib/models/user_model.dart
class UserModel {
  final int? id;
  final String fullName;
  final String email;
  final String phone;
  final String address;
  final String gender;

  UserModel({
    this.id,
    required this.fullName,
    required this.email,
    required this.phone,
    required this.address,
    required this.gender,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id:       map['id'] as int?,
      fullName: map['full_name'] as String,
      email:    map['email'] as String,
      phone:    map['phone'] as String,
      address:  map['address'] as String,
      gender:   map['gender'] as String,
    );
  }

  Map<String, dynamic> toMap() => {
    'full_name': fullName,
    'email':     email,
    'phone':     phone,
    'address':   address,
    'gender':    gender,
  };
}
