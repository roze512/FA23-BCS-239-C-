// lib/screens/form_screen.dart
import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/database_service.dart';
import 'records_screen.dart';

class FormScreen extends StatefulWidget {
  final UserModel? existingUser;
  const FormScreen({super.key, this.existingUser});

  @override
  State<FormScreen> createState() => _FormScreenState();
}

class _FormScreenState extends State<FormScreen> {
  final _formKey  = GlobalKey<FormState>();
  final _db       = DatabaseService();
  bool  _loading  = false;

  late final TextEditingController _nameCtrl;
  late final TextEditingController _emailCtrl;
  late final TextEditingController _phoneCtrl;
  late final TextEditingController _addressCtrl;
  String _gender = 'Male';

  @override
  void initState() {
    super.initState();
    final u = widget.existingUser;
    _nameCtrl    = TextEditingController(text: u?.fullName ?? '');
    _emailCtrl   = TextEditingController(text: u?.email    ?? '');
    _phoneCtrl   = TextEditingController(text: u?.phone    ?? '');
    _addressCtrl = TextEditingController(text: u?.address  ?? '');
    _gender      = u?.gender ?? 'Male';
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _addressCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final user = UserModel(
        id:       widget.existingUser?.id,
        fullName: _nameCtrl.text.trim(),
        email:    _emailCtrl.text.trim(),
        phone:    _phoneCtrl.text.trim(),
        address:  _addressCtrl.text.trim(),
        gender:   _gender,
      );
      if (widget.existingUser == null) {
        await _db.createRecord(user);
        _showSnack('Record created successfully!');
        _formKey.currentState!.reset();
        setState(() => _gender = 'Male');
      } else {
        await _db.updateRecord(user);
        _showSnack('Record updated successfully!');
        if (mounted) Navigator.pop(context, true);
      }
    } catch (e) {
      _showSnack('Error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red : Colors.green,
    ));
  }

  InputDecoration _deco(String label, IconData icon) => InputDecoration(
    labelText: label,
    prefixIcon: Icon(icon),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    filled: true,
    fillColor: Colors.grey.shade50,
  );

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existingUser != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Edit Record' : 'Submission Form'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
        actions: isEdit
            ? null
            : [
                IconButton(
                  icon: const Icon(Icons.list_alt),
                  tooltip: 'View Records',
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const RecordsScreen()),
                  ),
                )
              ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 12),

              // Full Name
              TextFormField(
                controller: _nameCtrl,
                decoration: _deco('Full Name', Icons.person),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Full name is required' : null,
              ),
              const SizedBox(height: 16),

              // Email
              TextFormField(
                controller: _emailCtrl,
                decoration: _deco('Email', Icons.email),
                keyboardType: TextInputType.emailAddress,
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return 'Email is required';
                  if (!RegExp(r'^[\w.]+@[\w]+\.[a-z]+$').hasMatch(v.trim()))
                    return 'Enter a valid email address';
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Phone
              TextFormField(
                controller: _phoneCtrl,
                decoration: _deco('Phone Number', Icons.phone),
                keyboardType: TextInputType.phone,
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return 'Phone number is required';
                  if (!RegExp(r'^\+?[0-9]{10,15}$').hasMatch(v.trim()))
                    return 'Enter a valid phone number';
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Address
              TextFormField(
                controller: _addressCtrl,
                decoration: _deco('Address', Icons.location_on),
                maxLines: 2,
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Address is required' : null,
              ),
              const SizedBox(height: 16),

              // Gender
              DropdownButtonFormField<String>(
                value: _gender,
                decoration: _deco('Gender', Icons.people),
                items: ['Male', 'Female', 'Other']
                    .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                    .toList(),
                onChanged: (v) => setState(() => _gender = v!),
              ),
              const SizedBox(height: 28),

              // Submit Button
              ElevatedButton.icon(
                onPressed: _loading ? null : _submit,
                icon: _loading
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white),
                      )
                    : Icon(isEdit ? Icons.save : Icons.send),
                label: Text(
                  isEdit ? 'Update Record' : 'Submit',
                  style: const TextStyle(fontSize: 16),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
