-- =============================================
-- Quiz 3 - Supabase SQL Setup
-- Run this in your Supabase SQL Editor
-- =============================================

CREATE TABLE submissions (
  id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  full_name   TEXT NOT NULL,
  email       TEXT NOT NULL,
  phone       TEXT NOT NULL,
  address     TEXT NOT NULL,
  gender      TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

-- Allow all operations (for development/testing)
CREATE POLICY "Allow all" ON submissions
  FOR ALL USING (true) WITH CHECK (true);
