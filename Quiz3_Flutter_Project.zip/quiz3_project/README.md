# Quiz 3 – Submission Form with Supabase Integration

## Setup Steps

### 1. Supabase Setup
- Go to https://supabase.com and create a new project
- Open the SQL Editor and run the contents of `supabase_setup.sql`
- Go to Project Settings > API and copy your **Project URL** and **anon key**

### 2. Add Your Credentials
Open `lib/supabase_config.dart` and replace:
```
supabaseUrl    → your Project URL
supabaseAnonKey → your anon/public key
```

### 3. Install Dependencies
```bash
flutter pub get
```

### 4. Run the App
```bash
flutter run
```

## Project Structure
```
lib/
├── main.dart
├── supabase_config.dart
├── models/
│   └── user_model.dart
├── screens/
│   ├── form_screen.dart
│   └── records_screen.dart
└── services/
    └── database_service.dart
```

## Features
- Submit form with Full Name, Email, Phone, Address, Gender
- Full CRUD: Create, Read, Update, Delete
- Form validation on all fields
- Records list screen with Edit and Delete options
- Supabase PostgreSQL database integration
