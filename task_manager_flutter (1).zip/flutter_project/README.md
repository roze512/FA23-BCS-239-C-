# Task Manager App — CSC303 Final Lab Project

A Flutter-based mobile application for managing tasks with **Firebase Firestore** integration.

---

## Features

- ✅ Splash Screen with animation
- ✅ View all tasks (Home Screen)
- ✅ Add new tasks with title, description, priority, and due date
- ✅ Edit existing tasks
- ✅ Delete tasks (swipe to delete)
- ✅ Mark tasks as complete/pending
- ✅ Filter tasks (All / Active / Completed)
- ✅ Task Detail Screen
- ✅ Statistics Screen (completion rate, priority breakdown)
- ✅ Firebase Firestore integration (CRUD)
- ✅ Real-time data updates using Streams

---

## Project Structure

```
lib/
├── main.dart                     # App entry point + Firebase init
├── firebase_options.dart         # Firebase configuration
├── models/
│   └── task_model.dart           # Task data model
├── services/
│   └── firestore_service.dart    # Firebase CRUD operations
├── screens/
│   ├── splash_screen.dart        # Animated splash screen
│   ├── home_screen.dart          # Main task list screen
│   ├── add_task_screen.dart      # Add/Edit task screen
│   ├── task_detail_screen.dart   # Task detail view
│   └── stats_screen.dart        # Statistics screen
└── widgets/
    ├── app_theme.dart            # App theme and colors
    └── task_card.dart            # Reusable task card widget
```

---

## Setup Instructions

### 1. Install Flutter
Make sure Flutter SDK is installed: https://flutter.dev/docs/get-started/install

### 2. Install Dependencies
```bash
flutter pub get
```

### 3. Setup Firebase

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a new project (e.g., `task-manager-app`)
3. Enable **Firestore Database** → Start in **Test Mode**
4. Install FlutterFire CLI:
   ```bash
   dart pub global activate flutterfire_cli
   ```
5. Run in project root:
   ```bash
   flutterfire configure
   ```
6. Replace `lib/firebase_options.dart` with the generated file

### 4. Run the App
```bash
flutter run
```

---

## Database Structure (Firestore)

**Collection:** `tasks`

| Field | Type | Description |
|-------|------|-------------|
| title | String | Task title |
| description | String | Task description |
| priority | String | "High", "Medium", or "Low" |
| isCompleted | Boolean | Completion status |
| createdAt | String | ISO date string |
| dueDate | String? | Optional due date |

---

## Screenshots
*(Add your 7+ screenshots here after running the app)*

---

## Student Info
- **Course:** CSC303 — Mobile Application Development
- **Project:** Final Lab Project (CLO-4)
- **Technology:** Flutter + Firebase Firestore
