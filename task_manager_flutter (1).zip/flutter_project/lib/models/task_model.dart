// lib/models/task_model.dart

class TaskModel {
  String? id;
  String title;
  String description;
  String priority; // 'High', 'Medium', 'Low'
  bool isCompleted;
  DateTime createdAt;
  DateTime? dueDate;

  TaskModel({
    this.id,
    required this.title,
    required this.description,
    required this.priority,
    this.isCompleted = false,
    required this.createdAt,
    this.dueDate,
  });

  // Convert TaskModel to Map (for Firestore)
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'priority': priority,
      'isCompleted': isCompleted,
      'createdAt': createdAt.toIso8601String(),
      'dueDate': dueDate?.toIso8601String(),
    };
  }

  // Create TaskModel from Firestore document
  factory TaskModel.fromMap(Map<String, dynamic> map, String docId) {
    return TaskModel(
      id: docId,
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      priority: map['priority'] ?? 'Medium',
      isCompleted: map['isCompleted'] ?? false,
      createdAt: DateTime.parse(map['createdAt']),
      dueDate: map['dueDate'] != null ? DateTime.parse(map['dueDate']) : null,
    );
  }
}
