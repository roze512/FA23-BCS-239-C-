// lib/services/firestore_service.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/task_model.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _collection = 'tasks';

  // CREATE - Add a new task
  Future<void> addTask(TaskModel task) async {
    await _firestore.collection(_collection).add(task.toMap());
  }

  // READ - Get all tasks as a stream (real-time updates)
  Stream<List<TaskModel>> getTasks() {
    return _firestore
        .collection(_collection)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => TaskModel.fromMap(doc.data(), doc.id))
          .toList();
    });
  }

  // READ - Get tasks by completion status
  Stream<List<TaskModel>> getTasksByStatus(bool isCompleted) {
    return _firestore
        .collection(_collection)
        .where('isCompleted', isEqualTo: isCompleted)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => TaskModel.fromMap(doc.data(), doc.id))
          .toList();
    });
  }

  // UPDATE - Update an existing task
  Future<void> updateTask(TaskModel task) async {
    await _firestore
        .collection(_collection)
        .doc(task.id)
        .update(task.toMap());
  }

  // UPDATE - Toggle task completion
  Future<void> toggleTaskCompletion(String taskId, bool currentStatus) async {
    await _firestore
        .collection(_collection)
        .doc(taskId)
        .update({'isCompleted': !currentStatus});
  }

  // DELETE - Delete a task
  Future<void> deleteTask(String taskId) async {
    await _firestore.collection(_collection).doc(taskId).delete();
  }

  // READ - Get tasks by priority
  Stream<List<TaskModel>> getTasksByPriority(String priority) {
    return _firestore
        .collection(_collection)
        .where('priority', isEqualTo: priority)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => TaskModel.fromMap(doc.data(), doc.id))
          .toList();
    });
  }
}
