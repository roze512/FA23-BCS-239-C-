# Quiz 4 – Supabase Registration & Login App
**Course:** CSC303 – Mobile Application Development  
**Platform:** Flutter + Supabase Authentication (Email-Based)

---

## 📱 Features

| Feature | Status |
|---|---|
| Registration Screen (Email, Password, Confirm Password) | ✅ |
| Login Screen (Email, Password) | ✅ |
| Home Screen (User ID, Email, Auth info) | ✅ |
| Supabase Email Auth – Register | ✅ |
| Supabase Email Auth – Login | ✅ |
| Supabase Email Auth – Logout | ✅ |
| Input Validation (empty, invalid email, weak password, mismatch) | ✅ |
| Success & Error Messages | ✅ |
| Email Confirmation Flow | ✅ |
| Authenticated User Info on Home Screen | ✅ |

---

## 🛠️ Setup Instructions

### 1. Prerequisites
- Flutter SDK ≥ 3.0.0 installed
- A Supabase account (free): https://supabase.com

### 2. Create Supabase Project
1. Go to https://app.supabase.com → New Project
2. Note your **Project URL** and **Anon Key** (Settings → API)

### 3. Enable Email Auth in Supabase
1. In your Supabase dashboard → **Authentication** → **Providers**
2. Enable **Email** provider
3. (Optional) Disable "Confirm email" for testing in Authentication → Settings

### 4. Configure the App
Open `lib/main.dart` and replace the placeholders:
```dart
await Supabase.initialize(
  url: 'https://YOUR_PROJECT_ID.supabase.co',  // ← your URL
  anonKey: 'YOUR_ANON_KEY',                     // ← your anon key
);
```

### 5. Install Dependencies & Run
```bash
flutter pub get
flutter run
```

---

## 📁 Project Structure

```
lib/
├── main.dart                    # App entry point, Supabase init
├── services/
│   └── auth_service.dart        # register, login, logout, currentUser
└── screens/
    ├── registration_screen.dart # Registration UI + validation
    ├── login_screen.dart        # Login UI + validation
    └── home_screen.dart         # User info dashboard + logout

Screenshots/
├── registration_screen.png
├── login_screen.png
├── home_screen.png
├── email_confirmation.png
└── supabase_auth_table.png
```

---

## 🔐 Input Validation Rules

| Field | Rules |
|---|---|
| Email | Required, valid format (x@x.x) |
| Password | Required, ≥ 6 characters, 1 uppercase, 1 number |
| Confirm Password | Must match password |

---

## 🎨 UI Theme
- Dark theme with Supabase brand green (#3ECF8E)
- Background: #0F1117
- Cards: #1C2131
- Clean, modern Material 3 design
