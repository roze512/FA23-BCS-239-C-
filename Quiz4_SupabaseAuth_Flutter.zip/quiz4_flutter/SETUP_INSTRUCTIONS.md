# SETUP INSTRUCTIONS – Supabase Flutter Auth App

## Step 1: Create Supabase Account & Project

1. Visit https://supabase.com → Sign Up (free)
2. Click **New Project** → Enter project name e.g. `flutter_auth`
3. Set a **database password** → Select a region → Create Project
4. Wait ~2 minutes for project to provision

---

## Step 2: Get Your API Keys

1. In Supabase Dashboard → **Settings** (gear icon) → **API**
2. Copy:
   - **Project URL** → e.g. `https://abcdefghijkl.supabase.co`
   - **anon / public key** → long JWT string starting with `eyJ...`

---

## Step 3: Configure Authentication

1. Go to **Authentication** → **Providers** → Enable **Email**
2. For testing: Go to **Authentication** → **Settings** → Disable **"Enable email confirmations"**  
   *(Or keep enabled to test email confirmation flow)*

---

## Step 4: Update lib/main.dart

```dart
await Supabase.initialize(
  url: 'https://YOUR_PROJECT_ID.supabase.co',
  anonKey: 'YOUR_ANON_KEY_HERE',
);
```

---

## Step 5: Run the App

```bash
# Install dependencies
flutter pub get

# Run on emulator or device
flutter run

# Run on Chrome (web)
flutter run -d chrome
```

---

## Step 6: View Registered Users

1. Supabase Dashboard → **Authentication** → **Users**
2. You will see all registered users with email, UUID, confirmed status, last sign-in

---

## Common Errors

| Error | Fix |
|---|---|
| `Invalid API key` | Double-check anon key in main.dart |
| `Email not confirmed` | Disable email confirmation in Supabase settings |
| `User already registered` | Try logging in instead |
| `Network error` | Check internet connection; verify Supabase URL |
