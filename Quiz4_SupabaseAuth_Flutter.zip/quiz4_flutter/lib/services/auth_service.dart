import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  final SupabaseClient _supabase = Supabase.instance.client;

  // ─── Register new user ───────────────────────────────────────────────────
  Future<AuthResponse> register({
    required String email,
    required String password,
  }) async {
    return await _supabase.auth.signUp(
      email: email,
      password: password,
    );
  }

  // ─── Login existing user ─────────────────────────────────────────────────
  Future<AuthResponse> login({
    required String email,
    required String password,
  }) async {
    return await _supabase.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }

  // ─── Logout ──────────────────────────────────────────────────────────────
  Future<void> logout() async {
    await _supabase.auth.signOut();
  }

  // ─── Get current user ────────────────────────────────────────────────────
  User? get currentUser => _supabase.auth.currentUser;

  // ─── Auth state stream ───────────────────────────────────────────────────
  Stream<AuthState> get authStateChanges => _supabase.auth.onAuthStateChange;
}
